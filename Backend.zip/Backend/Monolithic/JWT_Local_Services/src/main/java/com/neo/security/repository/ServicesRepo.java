package com.neo.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.neo.security.entity.Services;

public interface ServicesRepo extends JpaRepository<Services, Long>{


}
