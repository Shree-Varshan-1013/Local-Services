package com.neo.security.user;

public class Sample {

}
